# StoryVoice Android v1.1

A private Android text-to-speech project using Android's installed TTS engine. No app account, API key, subscription, or script upload is required.

## Features
- Long scripts: splits an 8–10 minute script into safe sections and queues them in one narration session.
- Installed English voice selector. Choose the deepest voice available on the phone.
- Speaking rate and pitch controls.
- Pause/story cues: `[pause]`, `[long pause]`, `[suspense]text[/suspense]`, `[dramatic]text[/dramatic]`.
- Listen in the app.
- Save a single WAV audio file to Music/StoryVoice using Android's TTS file synthesis.

## Honest limitations
- Android does not reliably expose voice gender or a true "deep male" tag. The voice selector lists offline English voices; the user must audition/select the voice that sounds deepest and most masculine on their device.
- The mood markers add phrasing/pause cues, not genuine AI emotional acting. The expressiveness is limited by the installed TTS voice.
- Export is WAV, not MP3. Android's built-in TTS does not guarantee an MP3 encoder. WAV is broadly supported and avoids adding a paid/cloud dependency.
- The export implementation expects the device's TTS engine to support `synthesizeToFile` and to emit standard WAV chunks in a consistent PCM format. Some OEM TTS engines may not support this.
- For fully offline operation, install an offline English voice in Android Settings > Text-to-speech output. Some system engines download voice data or use network services.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync; install Android SDK 35 if prompted.
3. Connect your Android phone or start an emulator.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK shown by Android Studio.

## Device setup
Android Settings > System / Additional settings > Languages & input > Text-to-speech output. Select your preferred engine, install offline English voice data, and audition the English voices in StoryVoice.

Package: `com.storyvoice.app` • Minimum Android: 8.0 (API 26)

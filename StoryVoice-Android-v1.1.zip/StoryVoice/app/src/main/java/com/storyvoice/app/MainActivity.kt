package com.storyvoice.app

import android.content.ContentValues
import android.media.AudioFormat
import android.media.AudioRecord
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import java.util.UUID

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready by mutableStateOf(false)
    private var status by mutableStateOf("Starting voice engine…")
    private var availableVoices by mutableStateOf<List<Voice>>(emptyList())
    private var chosenVoice by mutableStateOf<Voice?>(null)
    private var isSpeaking by mutableStateOf(false)
    private var isExporting by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                StoryVoiceScreen(
                    ready = ready, status = status, voices = availableVoices,
                    chosenVoice = chosenVoice, onVoice = { chosenVoice = it },
                    speaking = isSpeaking, exporting = isExporting,
                    onSpeak = { text, rate, pitch -> speakLongText(text, rate, pitch) },
                    onExport = { text, rate, pitch -> exportWav(text, rate, pitch) },
                    onStop = { tts?.stop(); isSpeaking = false; isExporting = false; status = "Stopped" }
                )
            }
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            engine.language = Locale.US
            val english = engine.voices
                ?.filter { it.locale.language == "en" && !it.isNetworkConnectionRequired }
                ?.sortedWith(compareBy<Voice>(
                    { if (it.name.contains("male", true)) 0 else 1 },
                    { -it.quality }, { it.name }
                )) ?: emptyList()
            availableVoices = english
            chosenVoice = english.firstOrNull()
            ready = true
            status = if (english.isEmpty()) "Ready. Install an offline English voice in Android TTS settings."
                     else "Ready • ${english.size} offline English voice(s) found"
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    runOnUiThread { isSpeaking = true }
                }
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "storyvoice_last") runOnUiThread {
                        isSpeaking = false
                        if (!isExporting) status = "Narration complete"
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread { isSpeaking = false; isExporting = false; status = "Voice engine error" }
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    runOnUiThread { isSpeaking = false; isExporting = false; status = "Voice engine error ($errorCode)" }
                }
            })
        } else status = "Text-to-Speech could not start. Check Android TTS settings."
    }

    private fun prepareEngine(rate: Float, pitch: Float) {
        val engine = tts ?: return
        engine.stop()
        chosenVoice?.let { engine.voice = it }
        engine.setSpeechRate(rate)
        engine.setPitch(pitch)
    }

    private fun speakLongText(raw: String, rate: Float, pitch: Float) {
        val engine = tts ?: return
        if (raw.isBlank() || !ready) return
        prepareEngine(rate, pitch)
        val chunks = splitForTts(applyPauseMarkers(raw), 2500)
        status = "Narrating ${chunks.size} sections…"
        chunks.forEachIndexed { index, chunk ->
            val id = if (index == chunks.lastIndex) "storyvoice_last" else "storyvoice_${UUID.randomUUID()}"
            engine.speak(chunk, if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    private fun exportWav(raw: String, rate: Float, pitch: Float) {
        if (raw.isBlank() || !ready) return
        val engine = tts ?: return
        prepareEngine(rate, pitch)
        isExporting = true
        isSpeaking = false
        val chunks = splitForTts(applyPauseMarkers(raw), 1800)
        val tempFiles = mutableListOf<File>()
        val session = UUID.randomUUID().toString()
        status = "Creating WAV audio…"
        var completed = 0

        fun finishIfReady() {
            if (completed != chunks.size) return
            Thread {
                try {
                    val out = File(cacheDir, "storyvoice_$session.wav")
                    mergeWavFiles(tempFiles, out)
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "StoryVoice_${System.currentTimeMillis()}.wav")
                        put(MediaStore.MediaColumns.MIME_TYPE, "audio/wav")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/StoryVoice")
                    }
                    val uri: Uri? = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri == null) throw IllegalStateException("Could not create audio file")
                    contentResolver.openOutputStream(uri)?.use { output -> out.inputStream().use { it.copyTo(output) } }
                        ?: throw IllegalStateException("Could not write audio file")
                    tempFiles.forEach { it.delete() }
                    out.delete()
                    runOnUiThread {
                        isExporting = false
                        status = "Saved WAV to Music/StoryVoice"
                    }
                } catch (e: Exception) {
                    runOnUiThread { isExporting = false; status = "Export failed: ${e.message}" }
                }
            }.start()
        }

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId?.startsWith("export_") == true) {
                    synchronized(tempFiles) {
                        completed++
                        finishIfReady()
                    }
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { isExporting = false; status = "Audio export failed in TTS engine" }
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                runOnUiThread { isExporting = false; status = "Audio export failed ($errorCode)" }
            }
        })

        chunks.forEachIndexed { index, chunk ->
            val file = File(cacheDir, "sv_${session}_$index.wav")
            tempFiles.add(file)
            val id = "export_$index"
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) }
            val result = engine.synthesizeToFile(chunk, params, file, id)
            if (result != TextToSpeech.SUCCESS) {
                isExporting = false
                status = "This Android voice engine does not support audio-file export."
                tempFiles.forEach { it.delete() }
                return
            }
        }
    }

    private fun applyPauseMarkers(text: String): String {
        return text
            .replace(Regex("\\[pause\\]", RegexOption.IGNORE_CASE), " … … ")
            .replace(Regex("\\[long pause\\]", RegexOption.IGNORE_CASE), " … … … ")
            .replace(Regex("\\[suspense\\](.*?)\\[/suspense\\]", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "$1 … ")
            .replace(Regex("\\[calm\\](.*?)\\[/calm\\]", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "$1")
            .replace(Regex("\\[dramatic\\](.*?)\\[/dramatic\\]", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "… $1 …")
    }

    private fun splitForTts(text: String, limit: Int): List<String> {
        var remaining = text
        val result = mutableListOf<String>()
        while (remaining.length > limit) {
            var cut = remaining.lastIndexOf(". ", limit)
            if (cut < limit / 2) cut = remaining.lastIndexOf("! ", limit)
            if (cut < limit / 2) cut = remaining.lastIndexOf("? ", limit)
            if (cut < limit / 2) cut = remaining.lastIndexOf(' ', limit)
            if (cut <= 0) cut = limit
            result += remaining.substring(0, cut + 1).trim()
            remaining = remaining.substring(cut + 1).trim()
        }
        if (remaining.isNotBlank()) result += remaining
        return result
    }

    // Join PCM WAV chunks into one WAV file. All chunks must use the same TTS output format.
    private fun mergeWavFiles(files: List<File>, output: File) {
        require(files.isNotEmpty()) { "No audio chunks were generated" }
        val chunks = files.map { it.readBytes() }
        val first = chunks.first()
        require(first.size > 44) { "TTS produced an invalid WAV file" }
        val pcm = chunks.map { bytes ->
            require(bytes.size > 44 && String(bytes, 0, 4) == "RIFF") { "Invalid WAV chunk" }
            bytes.copyOfRange(44, bytes.size)
        }
        val dataSize = pcm.sumOf { it.size }
        val header = first.copyOfRange(0, 44)
        putIntLE(header, 4, 36 + dataSize)
        putIntLE(header, 40, dataSize)
        RandomAccessFile(output, "rw").use { raf ->
            raf.setLength(0)
            raf.write(header)
            pcm.forEach { raf.write(it) }
        }
    }

    private fun putIntLE(a: ByteArray, offset: Int, value: Int) {
        for (i in 0..3) a[offset + i] = ((value ushr (8 * i)) and 0xff).toByte()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryVoiceScreen(
    ready: Boolean, status: String, voices: List<Voice>, chosenVoice: Voice?,
    onVoice: (Voice) -> Unit, speaking: Boolean, exporting: Boolean,
    onSpeak: (String, Float, Float) -> Unit,
    onExport: (String, Float, Float) -> Unit, onStop: () -> Unit
) {
    var script by remember { mutableStateOf("") }
    var rate by remember { mutableFloatStateOf(0.90f) }
    var pitch by remember { mutableFloatStateOf(0.78f) }
    var expanded by remember { mutableStateOf(false) }
    val words = script.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    val minutes = words / 135f
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("StoryVoice", style = MaterialTheme.typography.headlineLarge)
            Text("Private documentary narration studio", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("DEEP ENGLISH NARRATOR", style = MaterialTheme.typography.labelMedium)
                Text("Slow • Steady • Story-driven", style = MaterialTheme.typography.titleLarge)
                Text("Voice gender and natural emotion depend on the voices installed on your phone.")
            } }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(value = chosenVoice?.name ?: "Default English voice", onValueChange = {},
                    readOnly = true, label = { Text("Installed offline English voice") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    voices.forEach { voice ->
                        DropdownMenuItem(text = { Text(voice.name) }, onClick = { onVoice(voice); expanded = false })
                    }
                }
            }
            OutlinedTextField(value = script, onValueChange = { script = it },
                modifier = Modifier.fillMaxWidth().height(270.dp),
                label = { Text("Your complete script") },
                placeholder = { Text("Paste your 8–10 minute script here…\n\nUse [pause], [long pause], [suspense]…[/suspense] or [dramatic]…[/dramatic].") },
                minLines = 8)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$words words")
                Text("~${"%.1f".format(Locale.US, minutes)} min")
            }
            Text("Speaking speed • ${"%.2f".format(Locale.US, rate)}×")
            Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.72f..1.12f)
            Text("Lower pitch • ${"%.2f".format(Locale.US, pitch)}")
            Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.65f..1.10f)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onSpeak(script, rate, pitch) }, enabled = ready && script.isNotBlank() && !speaking && !exporting,
                    modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("Listen")
                }
                OutlinedButton(onClick = { onExport(script, rate, pitch) },
                    enabled = ready && script.isNotBlank() && !speaking && !exporting, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(5.dp)); Text("Save WAV")
                }
                OutlinedButton(onClick = onStop, enabled = speaking || exporting) {
                    Icon(Icons.Default.Stop, null)
                }
            }
            if (exporting) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(status, color = MaterialTheme.colorScheme.primary)
            HorizontalDivider()
            Text("Storytelling cues", style = MaterialTheme.typography.titleMedium)
            Text("[pause]  •  [long pause]  •  [suspense]words[/suspense]  •  [dramatic]words[/dramatic]")
            Text("These cues guide phrasing and pauses. The free Android TTS voice does not perform true human-like emotion.")
            Text("Private by design: this app does not upload your script or require an account. Use an offline voice for fully offline narration.")
        }
    }
}
